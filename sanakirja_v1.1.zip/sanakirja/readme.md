--- SANAVISA-SOVELLUKSEN ASENNUS- JA KÄYTTÖOHJE ---

SOVELLUKSEN KUVAUS:
	Sanavisa on suomi-englanti sanaharjoittelu-sovellus, joka pyörii selaimessa.

---

ASENNUS JA KÄYTTÖ:

1. PURKAMINEN:
	Pura zip-tiedosto haluamaasi kansioon, johon sinulla on käyttöoikeudet. Älä pura työpöydän juureen tai järjestelmäkansioihin.

2. TARKISTUS:
	Varmista että kansiossa on seuraavat kolme tiedostoa:
	- sovellus.exe
	- sanalista.json (Tallennetut sanaparit)
	- tilastot.json (Tallennetut pelitulokset)

3. KÄYNNISTYS:
	Käynnistä sovellus.exe

4. PALVELIN:
	Musta konsoli-ikkuna (palvelin) avautuu. **Älä sulje tätä ikkunaa!**
   	Kun näet konsolissa viestin "Running on...", avaa selain ja siirry osoitteeseen:

      		http://127.0.0.1:5000

5. LOPETUS: 
	Lopeta sovellus sulkemalla ensin selainikkuna ja sitten **sulje konsoli-ikkuna**.

---